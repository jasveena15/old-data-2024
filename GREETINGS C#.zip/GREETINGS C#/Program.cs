﻿using static System.Console;

/// <summary>
/// A Greeting captures a message that can be delivered to a recipient in the Terminal.
/// </summary>
class Greeting
{
    private string _message;

    public Greeting(string message)
    {
        _message = message;
    }

    public void Print()
    {
        WriteLine(_message);
    }

    public void Print(string name)
    {
        WriteLine($"Hello {name}! {_message}");
    }

    public string Message
    {
        get
        {
            return _message;
        }
        set
        {
            _message = value;
        }
    }

    static void Main(string[] args)
    {
        // Create an instance of Greeting and use it
        Greeting greeting = new Greeting("Welcome to our program!");
        greeting.Print();
        greeting.Print("Jasveena kaur");
    }
}
