import random

MAX_NUMBER = 100
MAX_GUESSES = 7

def play_game():
    my_number = random.randint(1, MAX_NUMBER)
    guess_number = 0

    print(f"I am thinking of a number between 1 and {MAX_NUMBER}\n")

    while guess_number < MAX_GUESSES:
        guess_number += 1
        guess = int(input(f"Guess {guess_number}: "))

        if my_number < guess:
            print(f"The number is less than {guess}")
        elif my_number > guess:
            print(f"The number is larger than {guess}")
        else:
            print(f"Well done... the number was {guess}")
            return

    print(f"You ran out of guesses... the number was {my_number}\n")

def main():
    while True:
        play_game()
        print("-" * 50)
        again = input("Do you want to play again [Y/n]? ").strip().lower()
        if again == 'n':
            break

    print("\nBye")

if __name__ == "__main__":
    main()
