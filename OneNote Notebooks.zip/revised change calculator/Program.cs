﻿using System;

class Program
{
    static void Main(string[] args)
    {
        const int NUM_COIN_TYPES = 6;
        const int TWO_DOLLARS = 200;
        const int ONE_DOLLAR = 100;
        const int FIFTY_CENTS = 50;
        const int TWENTY_CENTS = 20;
        const int TEN_CENTS = 10;
        const int FIVE_CENTS = 5;

        int[] coinValues = { TWO_DOLLARS, ONE_DOLLAR, FIFTY_CENTS, TWENTY_CENTS, TEN_CENTS, FIVE_CENTS };
        string[] coinTexts = { "$2", "$1", "50c", "20c", "10c", "5c" };
    

        string again;

        do
#pragma warning disable CS8602 // Dereference of a possibly null reference.
        {
            Console.WriteLine("Your cashier is Jasveena-224001588");

            int costOfItemDollars = GetIntegerInput("Enter the cost in dollars: ");
            int costOfItemCents = GetIntegerInput("Enter the cost in cents: ");
            int costOfItem = costOfItemDollars * 100 + costOfItemCents;

            int amountPaidDollars = GetIntegerInput("Enter the amount paid in dollars: ");
            int amountPaidCents = GetIntegerInput("Enter the amount paid in cents: ");
            int amountPaid = amountPaidDollars * 100 + amountPaidCents;

            if (amountPaid >= costOfItem)
            {
                int changeValue = amountPaid - costOfItem;
                Console.WriteLine("Change to give:");

                int i = 0;
                do
                {
                    int toGive = changeValue / coinValues[i];
                    changeValue -= toGive * coinValues[i];
                    Console.WriteLine($"{coinTexts[i]} coins: {toGive}");
                    i++;
                } while (i < NUM_COIN_TYPES);
            }
            else
            {
                Console.WriteLine("Insufficient payment. Please provide more.");
            }

            Console.Write("Do you want to run again? (Y/N): ");
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
            again = Console.ReadLine();
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.
        } while (again.ToUpper() != "N");
#pragma warning restore CS8602 // Dereference of a possibly null reference.
    }

    static int GetIntegerInput(string prompt)
    {
        int input;
        string line;
        bool isInteger;
        
        do
        {
            Console.Write(prompt);
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
            line = Console.ReadLine();
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.
            isInteger = int.TryParse(line, out input);

            if (!isInteger)
            {
                Console.WriteLine("Please enter whole numbers only.");
            }
        } while (!isInteger);

        return input;
    }
}
