﻿using static system.console;
using static system.convert;

// Declare variables
int costofitem;
//Get the details from the user.
// Get the cost (store in costofitem)
wirte("please enter the cost of the item: ");
costofitem = toint32(ReadLine());

// Get the amount paid (store in amountpaid)