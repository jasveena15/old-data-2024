#include "splashkit.h"
#include "utilities.h"
#include <string>

using namespace std;

// Product category enum
enum class ProductCategory {
    Dairy,
    Bakery,
    Snack,
    Frozen
};

// Product struct definition
struct Product {
    string name;
    string brand;
    ProductCategory category;
    int stockLevel;
};

// StorePOS struct definition
struct StorePOS {
    Product product;
    int saleCount;
};

// Function to add a new product
void addProduct(StorePOS& store) {
    write_line("Add Product");
    
    store.product.name = read_string("Enter product name: ");
    store.product.brand = read_string("Enter product brand: ");
    
    int categoryChoice = read_integer_range("Enter product category (0 = Dairy, 1 = Bakery, 2 = Snack, 3 = Frozen): ", 0, 3);
    store.product.category = static_cast<ProductCategory>(categoryChoice);
    
    store.product.stockLevel = read_integer("Enter product stock level: ");
    
    write_line("Product added successfully!");
}

// Function to print the last added product details
void printProduct(const StorePOS& store) {
    write_line("Last Added Product Details");
    write_line("Name: " + store.product.name);
    write_line("Brand: " + store.product.brand);

    string category;
    switch (store.product.category) {
        case ProductCategory::Dairy:
            category = "Dairy";
            break;
        case ProductCategory::Bakery:
            category = "Bakery";
            break;
        case ProductCategory::Snack:
            category = "Snack";
            break;
        case ProductCategory::Frozen:
            category = "Frozen";
            break;
    }
    write_line("Category: " + category);
    write_line("Stock Level: " + to_string(store.product.stockLevel));
}

int main() {
    StorePOS store = {}; // Initialize StorePOS instance

    while (true) {
        write_line("\nStore POS Menu:");
        write_line("1. Add Product");
        write_line("2. Print Last Added Product");
        write_line("3. Exit");

        int choice = read_integer_range("Enter your choice: ", 1, 3);

        switch (choice) {
            case 1:
                addProduct(store);
                break;
            case 2:
                printProduct(store);
                break;
            case 3:
                write_line("Exiting Store POS. Goodbye!");
                return 0;
            default:
                write_line("Invalid choice. Please try again.");
        }
    }

    return 0;
}
