﻿using System;

class Program
{
    const int MAX_NUMBER = 100;
    const int MAX_GUESSES = 7;

    static void PlayGame()
    {
        Random rand = new Random();
        int myNumber = rand.Next(1, MAX_NUMBER + 1);
        int guessNumber = 0;

        Console.WriteLine($"I am thinking of a number between 1 and {MAX_NUMBER}\n");

        while (guessNumber < MAX_GUESSES)
        {
            guessNumber++;
            Console.Write($"Guess {guessNumber}: ");
#pragma warning disable CS8604 // Possible null reference argument.
            int guess = int.Parse(Console.ReadLine());
#pragma warning restore CS8604 // Possible null reference argument.

            if (myNumber < guess)
            {
                Console.WriteLine($"The number is less than {guess}");
            }
            else if (myNumber > guess)
            {
                Console.WriteLine($"The number is larger than {guess}");
            }
            else
            {
                Console.WriteLine($"Well done... the number was {guess}");
                return;
            }
        }

        Console.WriteLine($"You ran out of guesses... the number was {myNumber}\n");
    }

    static void Main()
    {
        while (true)
        {
            PlayGame();
            Console.WriteLine(new string('-', 50));
            Console.Write("Do you want to play again [Y/n]? ");
#pragma warning disable CS8602 // Dereference of a possibly null reference.
            string again = Console.ReadLine().Trim().ToLower();
#pragma warning restore CS8602 // Dereference of a possibly null reference.
            if (again == "n")
                break;
        }

        Console.WriteLine("\nBye");
    }
}
