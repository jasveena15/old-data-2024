﻿using System;

class Program
{
    static void Main(string[] args)
    {
        const double FeetToMeters = 0.3048;

        bool repeat = true;
        while (repeat)
        {
            double value1, value2;
            string unit1, unit2;

            // Prompt user to enter values
            Console.WriteLine("Enter the first value:");
            double.TryParse(Console.ReadLine(), out value1);

            Console.WriteLine("Enter the unit for the first value (feet/meters):");
            unit1 = Console.ReadLine().ToLower();

            Console.WriteLine("Enter the second value:");
            double.TryParse(Console.ReadLine(), out value2);

            Console.WriteLine("Enter the unit for the second value (feet/meters):");
            unit2 = Console.ReadLine().ToLower();

            // Validate input units
            if ((unit1 != "feet" && unit1 != "meters") || (unit2 != "feet" && unit2 != "meters"))
            {
                Console.WriteLine("Invalid unit. Please enter 'feet' or 'meters'.");
                continue;
            }

            // Perform calculations based on user input
            Console.WriteLine("Select operation:");
            Console.WriteLine("1. Multiply");
            Console.WriteLine("2. Divide");
            Console.WriteLine("3. Add");
            Console.WriteLine("4. Subtract");
            Console.Write("Enter your choice: ");

            int choice;
            while (!int.TryParse(Console.ReadLine(), out choice))
            {
                Console.WriteLine("Invalid choice. Please enter a number.");
                Console.Write("Enter your choice: ");
            }

            double result;
            string operation;

            switch (choice)
            {
                case 1:
                    result = value1 * value2;
                    operation = "Multiplication";
                    break;
                case 2:
                    result = value1 / value2;
                    operation = "Division";
                    break;
                case 3:
                    result = value1 + value2;
                    operation = "Addition";
                    break;
                case 4:
                    result = value1 - value2;
                    operation = "Subtraction";
                    break;
                default:
                    result = 0;
                    operation = "Invalid operation";
                    break;
            }

            // Convert units if necessary
            if (unit1 == "feet" && unit2 == "meters")
            {
                value1 *= FeetToMeters;
                operation += " (converted to meters)";
            }
            else if (unit1 == "meters" && unit2 == "feet")
            {
                value2 *= FeetToMeters;
                operation += " (converted to feet)";
            }

            Console.WriteLine($"{operation} result: {result}");

            // Ask if user wants to perform more calculations
            Console.Write("Do you want to perform more calculations? (yes/no): ");
            string response = Console.ReadLine().ToLower();
            repeat = (response == "yes" || response == "y");
        }
    }
}
