# http_parser library

This code is imported from: https://github.com/arduino/ArduinoCore-mbed/tree/4.1.1/libraries/SocketWrapper/src/utility/http_parser

The code is shrinked in size by deleting all the unrelated code to url parse.
