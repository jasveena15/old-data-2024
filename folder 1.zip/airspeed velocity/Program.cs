﻿using static System.Console;
using static System.Convert;

// Declare contants
const int TWO_DOLLARS = 200;

// Declare variables
int costOfItem;
int amountPaid;
int changeValue;
int toGive;


//Get the details from the user.
// Get the cost (store in the costOfItem)
Write("Please enter the cost of the item: ");
costOfItem = ToInt16(ReadLine());

// Get the amount paid (store in amountPaid)
Write("Please enter the amount paid: ");
amountPaid = ToInt32(ReadLine());

WriteLine($"You paid {amountPaid} for the item that costs {costOfItem}");

// Calculate the amount of change to provide 
changeValue = amountPaid - costOfItem;

WriteLine($"You need {changeValue} change");

//Give change 
// Give $2 coins 

//Calculate the number of $2 coins to give 
toGive = changeValue / TWO_DOLLARS;

//Update the amount of change remaining to give
changeValue = changeValue - toGive * TWO_DOLLARS;
// Output the number OF $2 coins to give - using Write 
Write($"{toGive}x$2,");
WriteLine();
