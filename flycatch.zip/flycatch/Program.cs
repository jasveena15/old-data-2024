﻿using System;
using SplashKitSDK;

namespace SpiderGame
{
    class Program
    {
        // Constants for screen width and height
        const int SCREEN_WIDTH = 800;
        const int SCREEN_HEIGHT = 600;

        // Constants for spider size and movement speed
        const int SPIDER_RADIUS = 25;
        const int SPIDER_SPEED = 5;

        // Constants for fly size and movement speed
        const int FLY_RADIUS = 15;
        const int FLY_SPEED = 3;

        static void Main(string[] args)
        {
            // Open a new window
            Window gameWindow = new Window("Spider Game", SCREEN_WIDTH, SCREEN_HEIGHT);

            // Set initial spider position
            int spiderX = SCREEN_WIDTH / 2;
            int spiderY = SCREEN_HEIGHT / 2;

            // Set initial fly position
            int flyX = SCREEN_WIDTH / 2;
            int flyY = SCREEN_HEIGHT / 2;

            // Event loop
            while (!SplashKit.QuitRequested())
            {
                // Handle Input
                if (SplashKit.KeyDown(KeyCode.RightKey))
                {
                    spiderX += SPIDER_SPEED;
                }
                if (SplashKit.KeyDown(KeyCode.LeftKey))
                {
                    spiderX -= SPIDER_SPEED;
                }
                if (SplashKit.KeyDown(KeyCode.DownKey))
                {
                    spiderY += SPIDER_SPEED;
                }
                if (SplashKit.KeyDown(KeyCode.UpKey))
                {
                    spiderY -= SPIDER_SPEED;
                }

                if (SplashKit.KeyDown(KeyCode.UKey))
                {
                    flyY -= FLY_SPEED;
                }
                if (SplashKit.KeyDown(KeyCode.DKey))
                {
                    flyY += FLY_SPEED;
                }
                if (SplashKit.KeyDown(KeyCode.LKey))
                {
                    flyX -= FLY_SPEED;
                }
                if (SplashKit.KeyDown(KeyCode.RKey))
                {
                    flyX += FLY_SPEED;
                }

                // Check if the spider caught the fly
                if (SplashKit.CirclesIntersect(spiderX, spiderY, SPIDER_RADIUS, flyX, flyY, FLY_RADIUS))
                {
                    // Reset fly position
                    flyX = SplashKit.Rnd(SCREEN_WIDTH);
                    flyY = SplashKit.Rnd(SCREEN_HEIGHT);
                }

                // Clear the window
                gameWindow.Clear(Color.White);

                // Draw spider
                gameWindow.FillCircle(Color.Black, spiderX, spiderY, SPIDER_RADIUS);

                // Draw fly
                gameWindow.FillCircle(Color.Red, flyX, flyY, FLY_RADIUS);

                // Refresh the window to show it to the user
                gameWindow.Refresh();

                // Process events
                SplashKit.ProcessEvents();

                // Refresh screen to limit to 60 frames per second
                SplashKit.RefreshScreen(60);
            }

            // Close the window when the game loop ends
            gameWindow.Close();
        }
    }
}
