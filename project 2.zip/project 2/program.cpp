
#include <vector>
#include <algorithm>
#include "splashkit.h"

using namespace std;

// Enum for movie genres
enum Genre {
    ACTION,
    COMEDY,
    DRAMA,
    HORROR,
    ROMANCE,
    THRILLER
};

// Struct for a review
struct Review {
    string text;
    int score;
};

// Struct for a movie
struct Movie {
    string name;
    string description;
    Genre genre;
    vector<Review> reviews;
};

// Database struct to manage movies
struct Database {
    vector<Movie> movies;

    // Function to add a movie
    void addMovie(const Movie& movie) {
        movies.push_back(movie);
    }

    // Function to remove a movie
    void removeMovie(const string& name) {
        auto it = find_if(movies.begin(), movies.end(), [&](const Movie& movie) {
            return movie.name == name;
        });
        if (it != movies.end()) {
            movies.erase(it);
        }
    }

    // Function to modify a movie
    void modifyMovie(const string& name, const Movie& newMovie) {
        auto it = find_if(movies.begin(), movies.end(), [&](const Movie& movie) {
            return movie.name == name;
        });
        if (it != movies.end()) {
            *it = newMovie;
        }
    }

    // Function to display all movies
    void displayAllMovies() {
        for (const auto& movie : movies) {
            displayMovie(movie);
        }
    }

    // Function to display a single movie
    void displayMovie(const Movie& movie) {
        write_line("Name: " + movie.name);
        write_line("Description: " + movie.description);
        write_line("Genre: " + genreToString(movie.genre));
        write_line("Reviews: ");
        for (const auto& review : movie.reviews) {
            write_line("Score: " + to_string(review.score) + ", Review: " + review.text);
        }
    }

    // Function to filter movies by genre
    void displayMoviesByGenre(Genre genre) {
        for (const auto& movie : movies) {
            if (movie.genre == genre) {
                displayMovie(movie);
            }
        }
    }

    // Function to filter movies by average rating above a certain value
    void displayMoviesByRatingAbove(double rating) {
        for (const auto& movie : movies) {
            double avgRating = 0;
            for (const auto& review : movie.reviews) {
                avgRating += review.score;
            }
            avgRating /= movie.reviews.size();
            if (avgRating >= rating) {
                displayMovie(movie);
            }
        }
    }

    // Helper function to convert genre enum to string
    string genreToString(Genre genre) {
        switch (genre) {
            case ACTION: return "Action";
            case COMEDY: return "Comedy";
            case DRAMA: return "Drama";
            case HORROR: return "Horror";
            case ROMANCE: return "Romance";
            case THRILLER: return "Thriller";
            default: return "Unknown";
        }
    }
};

// Main function to simulate different screens
void run_program() {
    Database db;

    // Add sample movies
    db.addMovie({"Movie 1", "Description 1", ACTION, {{"Good movie", 8}, {"Not bad", 7}}});
    db.addMovie({"Movie 2", "Description 2", COMEDY, {{"Funny", 9}, {"Average", 5}}});
    db.addMovie({"Movie 3", "Description 3", DRAMA, {{"Touching", 9}, {"Emotional", 8}}});

    // Sample usage: Display all movies
    write_line("All Movies:");
    db.displayAllMovies();
    write_line("");

    // Sample usage: Display movies by genre
    write_line("Movies by Genre (Comedy):");
    db.displayMoviesByGenre(COMEDY);
    write_line("");

    // Sample usage: Display movies by rating above a certain value
    write_line("Movies by Rating Above 7:");
    db.displayMoviesByRatingAbove(7);
    write_line("");
}

int main() {
    run_program();
    return 0;
}
