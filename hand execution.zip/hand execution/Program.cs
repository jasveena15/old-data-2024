﻿using static System . Console ;
using static System . Convert ;
bool baby ; // Stores true or false
bool child ; // Stores true or false
double finalVal ;
int baseVal ;
int age ;
int height ;
Write ( " Enter age: " );
age = ToInt32 ( ReadLine () );
// ToInt32 () converts read value to an integer
Write ( " Enter height : " );
height = ToInt32 ( ReadLine () );
Write ( " Enter base value : ");
baseVal = ToInt32 ( ReadLine () );
baby = ( age <= 2 );
child = ! (( baby ) || ( age > 8 ));
if ( child ) {
if ( height < 130) {
finalVal = baseVal / 4;
}
else {
finalVal = baseVal / 2;
}
}
else if ( baby ) {
finalVal = baseVal / 10;
}
else if ( height < 180 ) {
finalVal = baseVal ;
}
else {
finalVal = baseVal * 2;
}
WriteLine ( $" Value : { finalVal }.");

