#include "utilities.h"
#include "splashkit.h"
#include <string>
using namespace std;

int read_integer(const string& prompt)
{
    string line = read_string(prompt);
    while (!is_integer(line))
    {
        write_line("Please enter a whole number.");
        line = read_string(prompt);
    }
    return stoi(line);
}

int read_integer_range(const string& prompt, int min_val, int max_val) {
    int value;
    while (true) {
        write(prompt);
        value = read_integer("");
        if (value >= min_val && value <= max_val) {
            break; // Valid input, break the loop
        } else {
            write_line("Invalid input. Please enter an integer between " + to_string(min_val) + " and " + to_string(max_val) + ".");
        }
    }
    return value;
}

string read_string(const string& prompt) {
    write(prompt);
    return read_line();
}

string read_product_category(const string& prompt) {
    string category;
    while (true) {
        category = read_string(prompt);
        if (category == "Dairy" || category == "Bakery" || category == "Snack" || category == "Frozen") {
            break; // Valid category, break the loop
        } else {
            write_line("Invalid category. Please enter one of the following: Dairy, Bakery, Snack, Frozen.");
        }
    }
    return category;
}
