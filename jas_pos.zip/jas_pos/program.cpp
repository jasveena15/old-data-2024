#include "splashkit.h"
#include <string>
#include "utilities.h"

using namespace std;

// Define the Product struct
struct Product {
    string name;
    string brand;
    string category;
    int stock_level;
};

// Define the StorePOS struct
struct StorePOS {
    Product product;
    int sale_count;
};

// Procedure to print menu
void print_menu() {
    write_line("POS System Menu:");
    write_line("1. Add Product");
    write_line("2. Print Product");
    write_line("3. Exit");
}

// Procedure to read and store product details
void add_product(StorePOS &store) {
    write_line("Enter product details:");
    
    store.product.name = read_string("Name: ");
    store.product.brand = read_string("Brand: ");
    store.product.category = read_product_category("Category (Dairy, Bakery, Snack, Frozen): ");
    store.product.stock_level = read_integer_range("Stock Level: ", 0, 1000);
}

// Procedure to print product details
void print_product(const StorePOS &store) {
    write_line("\nProduct Details:");
    write_line("Name: " + store.product.name);
    write_line("Brand: " + store.product.brand);
    write_line("Category: " + store.product.category);
    write_line("Stock Level: " + to_string(store.product.stock_level));
}

// Main function
int main() {
    StorePOS store = {}; // Initialize StorePOS
    int choice;

    // Display menu and prompt user for choice
    while (true) {
        print_menu();
        choice = read_integer_range("Enter your choice (1, 2, or 3): ", 1, 3);

        if (choice == 1) {
            add_product(store);
        } else if (choice == 2) {
            print_product(store);
        } else if (choice == 3) {
            write_line("Exiting POS System. Goodbye!");
            break;
        }
    }

    return 0;
}
