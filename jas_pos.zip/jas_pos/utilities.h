#ifndef UTILITIES_H
#define UTILITIES_H

#include <string>

using namespace std;

int read_integer_range(const string& prompt, int min_val, int max_val);
string read_string(const string& prompt);
string read_product_category(const string& prompt);
int read_integer(const string& prompt);

#endif // UTILITIES_H
