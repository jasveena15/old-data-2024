#include "splashkit.h"

int main()
{
    string name = "jasveena";
    string &ref = name; //string & is a reference
    string *ptr = &name; //string * is a pointer. & gets name address

    // Another string variable
    string other = "other";

    // Read the name in 3 different ways
    write_line(name);
    write_line(ref);
    write_line(*ptr); //Use * to read the value the pointer refers to

    // Update via reference
    ref = "test update";
    write_line(name);

    // Update via reference
    *ptr = "ptr update"; // Use * to update the value referred to
    write_line(name);

    // Change what ptr refers to
    ptr = &other; // Without * we can change that ptr refers to
    write_line(*ptr);

    return 0;
}